# rodder
A distro-independent (or distro-agonistic if you wanna be fancy), non-system package manager with custom repos, similar to Homebrew

# FAQ

## Why "rodder"?
Because a fishing rod grabs fish, similar to how a package manager grabs packages.
